const express = require("express");
const app = express();
const path =require("path");
const port = process.env.PORT || 3000
require("./db/conn");
const Product = require("./models/product");

const { json } = require("express");
const { log } = require("console");

//built in middleware
const staticPath =path.join(__dirname,"../public");

//register the hbs
app.use(express.static(staticPath));
//it through get the data from form and convert to json formate 
app.use(express.json());
app.use(express.urlencoded({extended:false}));
app.get("/",(req,res) => {
   res.render("index");
});
app.post("/", async (req,res) => { 
    try{
      
        const pro = new Product({
            name:req.body.name,
            email:req.body.email,
            phone:req.body.phone,
            amount:req.body.amount,
            data: req.body.data,
            status:"current",
        }) 
         console.log(req.body.email); 
        const result2 = await Product.findOne({email:req.body.email})
        console.log(result2);
         if(result2)
         {
            res.status(400).send("Order already presnet");
             
         }
         else
         {
            const result = await pro.save();
            res.sendFile(path.join(__dirname,'../public/congress.html'));
         }       
    }
    catch(error){
    res.status(400).send(error);
    }
});
app.get("/admin",(req,res) => {
    res.sendFile(path.join(__dirname,'../public/admin.html'));
 });
 app.get("/resultpage",(req,res) => {
    res.render("resultpage");
 });
 app.post("/admin", async (req,res) => {
    try{
        const email = "Shubhamdhoot333@gmail.com";
        const password ="03032000"; 
        email1=req.body.email,
        password1=req.body.pass;
        console.log(req.body.pass,req.body.email);

        if (email===req.body.email && password===req.body.pass)
        {
            console.log("yes");
            const result4 = await Product.find({status:"current"})
             console.log(result4);   
            
        }
        else
        {
            console.log("no");    
        }
    }catch(error)
    {
        res.status(400).send(error);   
    }

 });


app.listen(port, (req,res ) =>{
    console.log(`post number ${port}`);
});